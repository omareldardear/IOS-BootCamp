//
//  Enums.swift
//  ITunesSearch
//
//  Created by Omar ElDardear on 5/24/17.
//  Copyright © 2017 Omar ElDardear. All rights reserved.
//

import Foundation

enum SearchCategory :String {
    case all, musicTrack, ebook, software
}
enum SerchingState {
    case notStarted, loading, done
}
