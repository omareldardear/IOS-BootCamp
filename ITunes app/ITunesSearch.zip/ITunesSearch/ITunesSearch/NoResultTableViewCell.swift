//
//  NoResultTableViewCell.swift
//  ITunesSearch
//
//  Created by Omar ElDardear on 5/10/17.
//  Copyright © 2017 Omar ElDardear. All rights reserved.
//

import UIKit

class NoResultTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
   


}
