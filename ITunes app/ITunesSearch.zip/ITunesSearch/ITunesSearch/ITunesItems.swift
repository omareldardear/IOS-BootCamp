//
//  ITunesItems.swift
//  ITunesSearch
//
//  Created by Omar ElDardear on 5/10/17.
//  Copyright © 2017 Omar ElDardear. All rights reserved.
//

import UIKit

class ITunesItems: NSObject {
    
    var name = ""
    var artistName = ""
    var artworkSmallURL = ""
    var artworkLargeURL = ""
    var storeURL = ""
    var kind = ""
    var currency = ""
    var price = 0.0
    var genre = ""
    
    
    
    

}
