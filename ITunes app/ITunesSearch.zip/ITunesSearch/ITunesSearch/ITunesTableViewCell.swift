//
//  ITunesTableViewCell.swift
//  ITunesSearch
//
//  Created by Omar ElDardear on 5/10/17.
//  Copyright © 2017 Omar ElDardear. All rights reserved.
//

import UIKit

class ITunesTableViewCell: UITableViewCell {

    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var mImage: AsyncImageView!
    @IBOutlet weak var artist: UILabel!

    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure( item: ITunesItems) {
        name.text = item.name
        
        if item.artistName.isEmpty {
            artist.text = "Unknown"
        } else {
            artist.text = item.artistName
        }
        
        
       
        if let smallURL = URL(string: item.artworkSmallURL) {
             print(smallURL.absoluteString)
            mImage.imageURL=smallURL
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
    }
}
