//
//  DetailsViewController.swift
//  ITunesSearch
//
//  Created by Omar ElDardear on 5/10/17.
//  Copyright © 2017 Omar ElDardear. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {
    @IBOutlet weak var closeButton: UIButton!

    @IBOutlet weak var mGenre: UILabel!
    @IBOutlet weak var mType: UILabel!
    @IBOutlet weak var mArtistName: UILabel!
    @IBOutlet weak var mName: UILabel!
    @IBOutlet weak var mImage: UIImageView!
    
    var item : ITunesItems!
    
    
    @IBAction func CloseAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()


       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    func updateViews(){
        if let item = item {
            mName.text = item.name
            mArtistName.text = item.artistName
            mType.text = "Type :  " + item.kind
            mGenre.text = "Genre :  " + item.genre
            
            if let largeURL = URL(string: item.artworkLargeURL) {
                
            }
            
        }
       
        
    }
    

   
}
