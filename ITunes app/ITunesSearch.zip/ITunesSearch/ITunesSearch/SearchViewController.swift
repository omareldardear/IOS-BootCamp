//
//  SearchViewController.swift
//  ITunesSearch
//
//  Created by Omar ElDardear on 5/10/17.
//  Copyright © 2017 Omar ElDardear. All rights reserved.
//

import UIKit

class SearchViewController: UIViewController  {

    @IBOutlet weak var SearchBar: UISearchBar!
    @IBOutlet weak var segmentType: UISegmentedControl!
    @IBOutlet weak var tableView: UITableView!
    
    var state : SerchingState = .notStarted
    
    var mItems : [ITunesItems] = []
   

    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
       
        tableView.contentInset = UIEdgeInsets(top: 108, left: 0, bottom: 0, right: 0)
        
        
        var cellNib = UINib(nibName: TableViewCellsIdentifiers.LoadingCell, bundle: nil)
        tableView.register(cellNib, forCellReuseIdentifier: TableViewCellsIdentifiers.LoadingCell)
        
        cellNib = UINib(nibName: TableViewCellsIdentifiers.NoResultCell, bundle: nil)
        tableView.register(cellNib, forCellReuseIdentifier: TableViewCellsIdentifiers.NoResultCell)
        
        cellNib = UINib(nibName: TableViewCellsIdentifiers.ITunesCell, bundle: nil)
        tableView.register(cellNib, forCellReuseIdentifier: TableViewCellsIdentifiers.ITunesCell)
        
        
        tableView.rowHeight = 80
        
        SearchBar.becomeFirstResponder()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    @IBAction func CstegoryChanged(_ sender: UISegmentedControl) {
        let mURL = ITunesAPI.URLBuilder(searchText: SearchBar.text! , category: getCategory())
        WebService.GETRequest(mURL: mURL, mDelegate: self)
    }
    
    func getCategory() -> SearchCategory {
        switch segmentType.selectedSegmentIndex {
            
        case 0 :
            return .all
        case 1 :
            return .musicTrack
        case 2 :
            return .software
        case 3 :
            return .ebook
            
            
        default:
            return .all
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == SeguesIdentifiers.Search_Details {
            if state == .done  && mItems.count > 0 {
                let detailViewController = segue.destination as! DetailsViewController
                let indexPath = sender as! IndexPath
                let item = mItems[indexPath.row]
                detailViewController.item = item

            }
        }
    }

   
  
}

extension  SearchViewController : UITableViewDelegate {
    func tableView(_ tableView: UITableView,
                   didSelectRowAt indexPath: IndexPath) {
        SearchBar.resignFirstResponder()
        
        if view.window!.rootViewController!.traitCollection.horizontalSizeClass == .compact {
            tableView.deselectRow(at: indexPath, animated: true)
            performSegue(withIdentifier: SeguesIdentifiers.Search_Details , sender: indexPath)
            
        }
//        else {
//            if case .results(let list) = search.state {
//                splitViewDetail?.searchResult = list[indexPath.row]
//            }
//            if splitViewController!.displayMode != .allVisible {
//                hideMasterPane()
//            }
//        }
    }
    
    func tableView(_ tableView: UITableView,
                   willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        switch state {
        case .notStarted, .loading :
            return nil
        case .done:
            if mItems.count == 0
            {
                return nil
            }
            return indexPath
        }
    }

    
}

extension  SearchViewController : UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        let mURL = ITunesAPI.URLBuilder(searchText: searchBar.text! , category: getCategory())
        WebService.GETRequest(mURL: mURL, mDelegate: self)
        
    }
    
}

extension SearchViewController : UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch state {
        case .notStarted:
            return 0
        case .loading:
            return 1
        case .done:
            if(mItems.count == 0 ){
                return 1
            }else{
                return mItems.count
            }
        }

        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch state {
        case .notStarted:
            print("error")
            return UITableViewCell()
            
        case .loading:
            let cell = tableView.dequeueReusableCell(
                withIdentifier: TableViewCellsIdentifiers.LoadingCell,
                for: indexPath)
            
//            let spinner = cell.viewWithTag(100) as! UIActivityIndicatorView
//            spinner.startAnimating()
            return cell
            
        case .done:
            if(mItems.count == 0 ){
                return tableView.dequeueReusableCell(
                    withIdentifier: TableViewCellsIdentifiers.NoResultCell,
                    for: indexPath)
            }else{
                let cell = tableView.dequeueReusableCell(
                    withIdentifier: TableViewCellsIdentifiers.ITunesCell,
                    for: indexPath) as! ITunesTableViewCell
                
                let item = mItems[indexPath.row]
                cell.configure(item: item)
                return cell
            }
        }
    }
}

extension SearchViewController : WebServiceProtocol {
   
    
    func RequestStarted() {
        self.state = .loading
        self.tableView.reloadData()
        self.SearchBar.resignFirstResponder()
        
    }
    func RequestFinished(data: Data) {
       self.mItems = ITunesAPI.GetItemsFromData(data: data)!
        print(self.mItems.count)
        self.state = .done
        self.tableView.reloadData()
        
    }
    func Error() {
        let alert = UIAlertController(
            title: NSLocalizedString("oops...", comment: "Error alert: title"),
            message: NSLocalizedString("There was an error ", comment: "Error alert: message"),
            preferredStyle: .alert)
        
        let action = UIAlertAction(title: NSLocalizedString("OK", comment: "Error alert: OK"), style: .default, handler: nil)
        alert.addAction(action)
        
        present(alert, animated: true, completion: nil)
        
    }
}



