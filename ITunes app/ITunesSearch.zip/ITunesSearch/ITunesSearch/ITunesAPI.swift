//
//  ITunesAPI.swift
//  ITunesSearch
//
//  Created by Omar ElDardear on 5/24/17.
//  Copyright © 2017 Omar ElDardear. All rights reserved.
//

import Foundation

class ITunesAPI {
    static func URLBuilder(searchText : String , category : SearchCategory ) -> URL{
        var entity = ""
        if category != .all {
            entity=category.rawValue
        }
        let escapedSearchText = searchText.addingPercentEncoding(
            withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        let urlString = String(format: "https://itunes.apple.com/search?term=%@&limit=150&entity=%@", escapedSearchText, entity)
        
        let url = URL(string: urlString)
        print("URL: \(url!)")
        return url!
    }
    
    
    static func GetItemsFromData (data : Data) -> [ITunesItems]? {
        do{
            let dataObject = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            guard let results = dataObject?["results"] as? [Any] else {
                print("No Array Found")
                return []
            }
            var ResultsArray: [ITunesItems] = []
           
            for result in results {
                if let result = result as? [String: Any] {
                    
                    var tempObject: ITunesItems?
                    
                    if let wrapperType = result["wrapperType"] as? String {
                        switch wrapperType {
                        case "track":
                            tempObject = GetItem(track: result)
                        case "audiobook":
                            tempObject = GetItem(audiobook: result)
                        case "software":
                            tempObject = GetItem(software: result)
                        default:
                            break
                        }
                    } else if let kind = result["kind"] as? String, kind == "ebook" {
                        tempObject = GetItem(ebook: result)
                    }
                    
                    if let tempObject = tempObject {
                        print(tempObject.name)
                        ResultsArray.append(tempObject)
                        
                    }
                }
            }
           
            return ResultsArray
            
        }catch{
            print("JSON Error: \(error)")
            return nil
        }
        
        
    }
    
    
    
  
    
    static func GetItem(track dictionary: [String: Any]) -> ITunesItems {
        let searchResult = ITunesItems()
        
        searchResult.name = dictionary["trackName"] as! String
        searchResult.artistName = dictionary["artistName"] as! String
        searchResult.artworkSmallURL = dictionary["artworkUrl60"] as! String
        searchResult.artworkLargeURL = dictionary["artworkUrl100"] as! String
        searchResult.storeURL = dictionary["trackViewUrl"] as! String
        searchResult.kind = dictionary["kind"] as! String
        searchResult.currency = dictionary["currency"] as! String
        
        if let price = dictionary["trackPrice"] as? Double {
            searchResult.price = price
        }
        if let genre = dictionary["primaryGenreName"] as? String {
            searchResult.genre = genre
        }
        return searchResult
    }
    
    static func GetItem(audiobook dictionary: [String: Any]) -> ITunesItems {
        let searchResult = ITunesItems()
        searchResult.name = dictionary["collectionName"] as! String
        searchResult.artistName = dictionary["artistName"] as! String
        searchResult.artworkSmallURL = dictionary["artworkUrl60"] as! String
        searchResult.artworkLargeURL = dictionary["artworkUrl100"] as! String
        searchResult.storeURL = dictionary["collectionViewUrl"] as! String
        searchResult.kind = "audiobook"
        searchResult.currency = dictionary["currency"] as! String
        
        if let price = dictionary["collectionPrice"] as? Double {
            searchResult.price = price
        }
        if let genre = dictionary["primaryGenreName"] as? String {
            searchResult.genre = genre
        }
        return searchResult
    }
    
    static func GetItem(software dictionary: [String: Any]) -> ITunesItems {
        let searchResult = ITunesItems()
        searchResult.name = dictionary["trackName"] as! String
        searchResult.artistName = dictionary["artistName"] as! String
        searchResult.artworkSmallURL = dictionary["artworkUrl60"] as! String
        searchResult.artworkLargeURL = dictionary["artworkUrl100"] as! String
        searchResult.storeURL = dictionary["trackViewUrl"] as! String
        searchResult.kind = dictionary["kind"] as! String
        searchResult.currency = dictionary["currency"] as! String
        
        if let price = dictionary["price"] as? Double {
            searchResult.price = price
        }
        if let genre = dictionary["primaryGenreName"] as? String {
            searchResult.genre = genre
        }
        return searchResult
    }
    
    static func GetItem(ebook dictionary: [String: Any]) -> ITunesItems {
        let searchResult = ITunesItems()
        searchResult.name = dictionary["trackName"] as! String
        searchResult.artistName = dictionary["artistName"] as! String
        searchResult.artworkSmallURL = dictionary["artworkUrl60"] as! String
        searchResult.artworkLargeURL = dictionary["artworkUrl100"] as! String
        searchResult.storeURL = dictionary["trackViewUrl"] as! String
        searchResult.kind = dictionary["kind"] as! String
        searchResult.currency = dictionary["currency"] as! String
        
        if let price = dictionary["price"] as? Double {
            searchResult.price = price
        }
        if let genres: Any = dictionary["genres"] {
            searchResult.genre = (genres as! [String]).joined(separator: ", ")
        }
        return searchResult
    }

}
