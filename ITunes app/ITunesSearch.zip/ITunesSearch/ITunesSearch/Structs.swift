//
//  Structs.swift
//  ITunesSearch
//
//  Created by Omar ElDardear on 5/10/17.
//  Copyright © 2017 Omar ElDardear. All rights reserved.
//

import Foundation



struct TableViewCellsIdentifiers {
    static let LoadingCell = "LoadingCell"
    static let NoResultCell = "NoResultCell"
    static let ITunesCell = "ITunesCell"
}
struct SeguesIdentifiers {
    static let Search_Details = "Search_Details"
}
