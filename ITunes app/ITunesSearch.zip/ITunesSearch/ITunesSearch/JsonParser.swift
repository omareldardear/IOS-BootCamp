//
//  JsonParser.swift
//  ITunesSearch
//
//  Created by Omar ElDardear on 5/24/17.
//  Copyright © 2017 Omar ElDardear. All rights reserved.
//

import Foundation

private func parse(Object data: Data) -> [String: Any]? {
    do {
        return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
    } catch {
        print("JSON Error: \(error)")
        return nil
    }
}
